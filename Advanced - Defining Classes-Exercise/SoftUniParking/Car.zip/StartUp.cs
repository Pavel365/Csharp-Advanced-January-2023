﻿using System;

namespace SoftUniParking
{
    public class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
